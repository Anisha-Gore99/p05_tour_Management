export default function AdminHome(){
    return(
        <div>
            <h1>Welcome to Admin Home Page</h1>
        </div>
    )
}