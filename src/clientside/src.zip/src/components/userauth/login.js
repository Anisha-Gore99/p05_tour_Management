import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { login } from "../../Reduxfeatures/slice";
import { useNavigate, useLocation } from "react-router-dom";

export default function Login() {
  const [uname, setUname] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState(null);
  const [loading, setLoading] = useState(false);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  // Helper: robust role normalization
  const normalizeRole = (user) => {
    const raw =
      user?.rid?.rname ??
      user?.role ??
      user?.roleName ??
      user?.role?.name;
    return typeof raw === "string" ? raw.toLowerCase() : "";
  };

  // Compute a clean "from" target (avoid looping to / or /login)
  const rawFrom = location.state?.from;
  const from =
    typeof rawFrom === "string" &&
    rawFrom !== "/" &&
    rawFrom !== "/login"
      ? rawFrom
      : null;

  const doLogin = async (e) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);

    try {
      // 1) Authenticate user
      const resp = await fetch("http://localhost:8081/api/user/chkLogin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uname, password }),
      });

      if (!resp.ok) throw new Error("Invalid credentials");

      const user = await resp.json();
      // Example shape:
      // { uid, uname, email, phone_no, rid: { rid, rname: 'tourist'|'admin'|'agency' } }

      // 2) Persist session
      localStorage.setItem("loggedUser", JSON.stringify(user));

      // 3) If tourist, fetch and persist tourist profile
      const role = normalizeRole(user);
      if (role === "tourist") {
        const uid = user?.uid ?? user?.id;
        if (uid) {
          try {
            const tResp = await fetch(
              `http://localhost:8081/tourist/getTouristByUserId?uid=${uid}`
            );
            if (tResp.ok) {
              const tourist = await tResp.json();
              localStorage.setItem("loggedTourist", JSON.stringify(tourist));
            }
          } catch {
            // Non-fatal: keep login session even if profile fetch fails
          }
        }
      }

      // 4) Update Redux
      dispatch(login());

      // 5) Navigate: Prefer returning to protected page; else role-based home
      if (from) {
        navigate(from, { replace: true });
      } else if (role === "admin") {
        navigate("/adminhome", { replace: true });
      } else if (role === "tourist") {
        navigate("/touristhome", { replace: true });
      } else if (role === "agency" || role === "touragency" || role === "agencyowner") {
        navigate("/agencyhome", { replace: true });
      } else {
        // sensible default if role missing/unknown
        navigate("/touristhome", { replace: true });
      }
    } catch (e) {
      console.error(e);
      setErr(e.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 420, margin: "0 auto" }}>
      <h2>Login</h2>
      {err && <div style={{ color: "crimson", marginBottom: 8 }}>{err}</div>}
      <form onSubmit={doLogin} style={{ display: "grid", gap: 12 }}>
        <label>
          Username
          <input
            type="text"
            value={uname}
            onChange={(e) => setUname(e.target.value)}
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <button type="submit" disabled={loading}>
          {loading ? "Signing in…" : "Login"}
        </button>
      </form>
    </div>
  );
}
