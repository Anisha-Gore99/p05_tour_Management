import React, { useState, useMemo } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function TouristReg() {
  const navigate = useNavigate();

  const [tourist, setTourist] = useState({
    fname: "",
    lname: "",
    address: "",
    dob: "",
    uid: {
      uname: "",
      email: "",
      password: "",
      phoneNo: ""
    }
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    const userFields = ["uname", "email", "password", "phoneNo"];
    if (userFields.includes(name)) {
      setTourist((prev) => ({ ...prev, uid: { ...prev.uid, [name]: value } }));
    } else {
      setTourist((prev) => ({ ...prev, [name]: value }));
    }
  };

  const canSubmit = useMemo(() => {
    const t = tourist;
    return (
      t.fname.trim() &&
      t.lname.trim() &&
      t.address.trim() &&
      t.dob &&
      t.uid.uname.trim() &&
      t.uid.email.trim() &&
      t.uid.password.trim() &&
      /^\d{10}$/.test(t.uid.phoneNo || "")
    );
  }, [tourist]);

  const sendData = async () => {
    const payload = {
      ...tourist,
      uid: {
        ...tourist.uid,
        phoneNo: (tourist.uid.phoneNo || "").replace(/\D/g, "")
      }
    };

    // Debug: see exactly what you’re sending
    console.log("Tourist payload →", payload);

    try {
      const res = await axios.post(
        "http://localhost:8081/tourist/registertourist",
        payload,
        { headers: { "Content-Type": "application/json" } }
      );
      alert("Registration successful!");
      // reset
      setTourist({
        fname: "",
        lname: "",
        address: "",
        dob: "",
        uid: { uname: "", email: "", password: "", phoneNo: "" }
      });
      navigate("/");
    } catch (error) {
      console.error("Error registering tourist:", error.response || error);
      // Show server’s message if available (e.g. “Email already exists”)
      const serverMsg =
        error?.response?.data && typeof error.response.data === "string"
          ? error.response.data
          : error?.response?.data?.message || error?.message || "Bad Request";
      alert(serverMsg);
    }
  };

  return (
    <div>
      <h2>Tourist Registration</h2>

      <input
        type="text"
        name="fname"
        placeholder="First Name"
        value={tourist.fname}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="lname"
        placeholder="Last Name"
        value={tourist.lname}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="address"
        placeholder="Address"
        value={tourist.address}
        onChange={handleChange}
        required
      />
      <input
        type="date"
        name="dob"
        placeholder="Date of Birth"
        value={tourist.dob}
        onChange={handleChange}
        required
      />

      <input
        type="text"
        name="uname"
        placeholder="Username"
        value={tourist.uid.uname}
        onChange={handleChange}
        required
      />
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={tourist.uid.email}
        onChange={handleChange}
        required
      />
      <input
        type="password"
        name="password"
        placeholder="Password"
        value={tourist.uid.password}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="phoneNo"
        placeholder="Phone No"
        value={tourist.uid.phoneNo}
        onChange={handleChange}
        pattern="[0-9]{10}"
        required
      />

      <button onClick={sendData} disabled={!canSubmit}>
        Register
      </button>
    </div>
  );
}
