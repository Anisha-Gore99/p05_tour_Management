import { useEffect, useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import { useSelector } from "react-redux";

export default function TouristHome() {
  const [tourist, setTourist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const loggedIn = useSelector(s => s?.logged?.loggedIn);

  useEffect(() => {
    // If not logged in, don't fetch; show Guest
    if (!loggedIn) {
      setTourist(null);
      setLoading(false);
      return;
    }

    let loggedUser = null;
    try {
      loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
    } catch (e) {
      setError("Corrupted login session. Please log in again.");
      setLoading(false);
      return;
    }

    const uid = loggedUser?.uid ?? loggedUser?.id;
    if (!uid) {
      setError("User ID missing. Please log in again.");
      setLoading(false);
      return;
    }

    fetch(`http://localhost:8081/tourist/getTouristByUserId?uid=${uid}`)
      .then(resp => {
        if (!resp.ok) throw new Error("Server error");
        return resp.json();
      })
      .then(obj => {
        localStorage.setItem("loggedTourist", JSON.stringify(obj));
        setTourist(obj);
        setLoading(false);
      })
      .catch(err => {
        setError("Failed to load tourist data.");
        console.error(err);
        setLoading(false);
      });

  }, [loggedIn]);

  return (
    <div>
      <header><h2>Tourist Dashboard</h2></header>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <nav style={{ display: "flex", gap: "1rem", marginBottom: "1rem" }}>
        <Link to="/viewalltours">View Tours</Link>
        <Link to="/bookinghistory">Booking History</Link>
        <Link to="/logout">Logout</Link>
      </nav>

      <section className="hero">
        <h1>
          Welcome,&nbsp;
          {loading
            ? 'Loading…'
            : tourist
              ? `${tourist.fname ?? ""} ${tourist.lname ?? ""}`.trim() || "Tourist"
              : 'Guest'}
        </h1>
        <Outlet />
      </section>
    </div>
  );
}
