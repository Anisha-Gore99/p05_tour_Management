import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

const BookingPage = () => {
  const { scheduleId } = useParams();
  const navigate = useNavigate();

  const storedTourist = JSON.parse(localStorage.getItem("loggedTourist"));
  const [touristId] = useState(storedTourist?.touristId || "");
  const [modeId, setModeId] = useState("");
  const [numTourists, setNumTourists] = useState(1);
  const [touristDetails, setTouristDetails] = useState([
    { fname: "", lname: "", age: "", gender: "", idProof: "" }
  ]);

  const handleNumTouristsChange = (e) => {
    const value = parseInt(e.target.value) || 1;
    setNumTourists(value);

    const updated = [...touristDetails];
    while (updated.length < value) {
      updated.push({ fname: "", lname: "", age: "", gender: "", idProof: "" });
    }
    while (updated.length > value) {
      updated.pop();
    }
    setTouristDetails(updated);
  };

  const handleTouristDetailChange = (index, field, value) => {
    const updated = [...touristDetails];
    updated[index][field] = value;
    setTouristDetails(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const bookingData = {
      touristId: parseInt(touristId),
      scheduleId: parseInt(scheduleId),
      modeId: parseInt(modeId),
      touristDetails: touristDetails
    };

    try {
      const res = await fetch("http://localhost:8080/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData)
      });

      if (res.ok) {
        alert("Booking successful!");
        navigate("/");
      } else {
        alert("Booking failed!");
      }
    } catch (err) {
      console.error("Error:", err);
      alert("Something went wrong!");
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Book Tour</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Tourist ID:</label>
          <input type="text" value={touristId} disabled />
        </div>

        <div>
          <label>Schedule ID:</label>
          <input type="text" value={scheduleId} disabled />
        </div>

        <div>
          <label>Mode ID:</label>
          <input
            type="number"
            value={modeId}
            onChange={(e) => setModeId(e.target.value)}
            required
          />
        </div>

        <div>
          <label>No. of Tourists:</label>
          <input
            type="number"
            min="1"
            value={numTourists}
            onChange={handleNumTouristsChange}
          />
        </div>

        <h3>Tourist Details</h3>
        {touristDetails.map((tourist, index) => (
          <div key={index} style={{ border: "1px solid #ccc", padding: "10px", marginBottom: "10px" }}>
            <p>Tourist #{index + 1}</p>
            <input
              type="text"
              placeholder="First Name"
              value={tourist.fname}
              onChange={(e) => handleTouristDetailChange(index, "fname", e.target.value)}
              required
            />
            <input
              type="text"
              placeholder="Last Name"
              value={tourist.lname}
              onChange={(e) => handleTouristDetailChange(index, "lname", e.target.value)}
              required
            />
            <input
              type="number"
              placeholder="Age"
              value={tourist.age}
              onChange={(e) => handleTouristDetailChange(index, "age", e.target.value)}
              required
            />
            <select
              value={tourist.gender}
              onChange={(e) => handleTouristDetailChange(index, "gender", e.target.value)}
              required
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
            <input
              type="text"
              placeholder="ID Proof"
              value={tourist.idProof}
              onChange={(e) => handleTouristDetailChange(index, "idProof", e.target.value)}
              required
            />
          </div>
        ))}

        <button type="submit">Confirm Booking</button>
      </form>
    </div>
  );
};

export default BookingPage;
