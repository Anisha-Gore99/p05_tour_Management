import React, { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { fetchTourById, fetchScheduleByPackageId } from "../../api/TourApi";
import { useSelector } from "react-redux";

const TourDetails = () => {
  // Support both /tours/:id and /tourdetails/:packageId
  const { id, packageId } = useParams();
  const effectivePackageId = packageId || id;

  const [tour, setTour] = useState(null);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  const [showModal, setShowModal] = useState(false);
  const [pendingScheduleId, setPendingScheduleId] = useState(null);

  const mystate = useSelector((state) => state?.logged);
  const loggedIn = !!mystate?.loggedIn;
  const navigate = useNavigate();

  // Normalize schedule objects regardless of snake_case or camelCase from API
  const normalizedSchedules = useMemo(() => {
    return (schedules || []).map((s) => ({
      scheduleId: s.scheduleId ?? s.schedule_id,
      startDate: s.startDate ?? s.start_date,
      endDate: s.endDate ?? s.end_date,
      available: s.availableSeats ?? s.available_bookings ?? s.available,
      cost: s.cost ?? s.price ?? s.amount,
    }));
  }, [schedules]);

  useEffect(() => {
    let active = true;
    (async () => {
      if (!effectivePackageId) {
        setErr("No package ID found in URL.");
        setLoading(false);
        return;
      }
      setLoading(true);
      setErr(null);
      try {
        const tourData = await fetchTourById(effectivePackageId);
        const scheduleData = await fetchScheduleByPackageId(effectivePackageId);
        if (!active) return;
        setTour(tourData);
        setSchedules(Array.isArray(scheduleData) ? scheduleData : []);
      } catch (e) {
        if (!active) return;
        console.error("Failed to load tour details:", e);
        setErr("Failed to load tour details.");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [effectivePackageId]);

  const handleBookClick = (scheduleId) => {
    if (!scheduleId) return;
    if (loggedIn) {
      navigate(`/booking/${scheduleId}`);
    } else {
      setPendingScheduleId(scheduleId);
      setShowModal(true);
    }
  };

  const handleModalChoice = (choice) => {
    setShowModal(false);
    if (choice === "login") {
      navigate("/login", { state: { from: `/tours/${effectivePackageId}` } });
    } else if (choice === "register") {
      navigate("/register", { state: { from: `/tours/${effectivePackageId}` } });
    } else {
      setPendingScheduleId(null); // cancel
    }
  };

  if (loading) return <p style={{ padding: 16 }}>Loading tour details…</p>;
  if (err) return <p style={{ padding: 16, color: "crimson" }}>{err}</p>;
  if (!tour) return <p style={{ padding: 16 }}>Tour not found.</p>;

  const title = tour.packageName || tour.pname || "Tour Package";

  return (
    <div className="tour-details-container" style={{ padding: 16 }}>
      <h2 style={{ marginTop: 0 }}>{title}</h2>
      {tour.destination && (
        <p><strong>Destination:</strong> {tour.destination}</p>
      )}
      {tour.description && (
        <p><strong>Description:</strong> {tour.description}</p>
      )}

      <h3>Available Schedules</h3>
      {normalizedSchedules.length === 0 ? (
        <p>No schedules available.</p>
      ) : (
        <ul className="schedule-list" style={{ listStyle: "none", padding: 0, display: "grid", gap: 12 }}>
          {normalizedSchedules.map((s) => (
            <li key={s.scheduleId} style={{ border: "1px solid #eee", borderRadius: 10, padding: 12 }}>
              <div>From: {s.startDate}</div>
              <div>To: {s.endDate}</div>
              <div>Seats Available: {s.available ?? "-"}</div>
              {s.cost !== undefined && <div>Cost: ₹{s.cost}</div>}
              <button
                disabled={(s.available ?? 0) <= 0}
                onClick={() => handleBookClick(s.scheduleId)}
                style={{ marginTop: 8 }}
              >
                {(s.available ?? 0) <= 0 ? "Sold Out" : "Book Now"}
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Simple modal */}
      {showModal && (
        <div
          className="tour-modal-backdrop"
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,.35)",
            display: "grid",
            placeItems: "center",
            zIndex: 9999,
          }}
        >
          <div
            className="tour-modal-content"
            style={{ background: "#fff", padding: 20, borderRadius: 12, width: 360 }}
          >
            <h4 style={{ marginTop: 0 }}>Login or Register to continue</h4>
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button onClick={() => handleModalChoice("login")}>Login</button>
              <button onClick={() => handleModalChoice("register")}>Register</button>
              <button onClick={() => handleModalChoice("cancel")}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TourDetails;
