package com.cdac.projectp05tourmanagement.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoleController {

}
