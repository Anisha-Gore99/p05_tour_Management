package com.cdac.projectp05tourmanagement.serverside;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServersideApplicationTests {

	@Test
	void contextLoads() {
	}

}
